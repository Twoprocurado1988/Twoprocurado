// Placeholder para imagens
// Este arquivo cria imagens de placeholder para o site

const fs = require('fs');
const path = require('path');
const { createCanvas } = require('canvas');

// Diretório de destino
const outputDir = path.join(__dirname, 'public', 'images');

// Função para criar uma imagem de placeholder
function createPlaceholderImage(filename, width, height, text, bgColor = '#222222', textColor = '#ffffff') {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Fundo
  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, width, height);
  
  // Efeito de gradiente
  const gradient = ctx.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, 'rgba(57, 255, 20, 0.1)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0.3)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
  
  // Texto
  ctx.fillStyle = textColor;
  ctx.font = 'bold 24px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, width / 2, height / 2);
  
  // Salvar a imagem
  const buffer = canvas.toBuffer('image/jpeg');
  fs.writeFileSync(path.join(outputDir, filename), buffer);
  
  console.log(`Created placeholder image: ${filename}`);
}

// Verificar se o diretório existe
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Criar placeholders para álbuns
createPlaceholderImage('album1.jpg', 500, 500, 'A Bandida e o Procurado');
createPlaceholderImage('album2.jpg', 500, 500, 'Limbo');

// Criar placeholders para galeria
for (let i = 1; i <= 12; i++) {
  createPlaceholderImage(`placeholder${i}.jpg`, 400, 400, `TW O Procurado ${i}`);
}

console.log('All placeholder images created successfully!');
