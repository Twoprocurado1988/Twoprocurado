# Site TW O Procurado - Instruções para Implantação na Vercel

Este repositório contém o código-fonte do site oficial de TW O Procurado, artista de trap brasileiro.

## Tecnologias Utilizadas

- Next.js
- React
- Tailwind CSS
- TypeScript

## Estrutura do Site

O site inclui as seguintes páginas:

- **Home**: Página inicial com destaque para músicas recentes e próximos shows
- **Música**: Discografia completa com player integrado
- **Agenda**: Calendário de shows e eventos
- **Galeria**: Fotos e vídeos
- **Biografia**: História e informações sobre o artista
- **Contato**: Formulário de contato e informações para booking

## Como Implantar na Vercel

1. Crie uma conta na [Vercel](https://vercel.com/signup)
2. Após fazer login, clique em "Add New..." e depois em "Project"
3. Conecte sua conta GitHub (se ainda não estiver conectada)
4. Selecione este repositório
5. Clique em "Deploy"

A Vercel detectará automaticamente que é um projeto Next.js e configurará tudo corretamente. Em poucos minutos, seu site estará online com um domínio vercel.app.

## Personalização

Para personalizar o site:

1. Substitua as imagens de placeholder por fotos reais do artista
2. Atualize as informações de contato
3. Adicione suas músicas e vídeos
4. Atualize a agenda de shows

## Suporte

Para qualquer dúvida ou suporte adicional, entre em contato através do formulário no site.
