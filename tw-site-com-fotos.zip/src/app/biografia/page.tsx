import React from 'react';
import Newsletter from '@/components/Newsletter';

export default function BiografiaPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-white mb-8">Biografia</h1>
      
      {/* Hero da Biografia */}
      <section className="mb-16">
        <div className="relative aspect-video rounded-lg overflow-hidden mb-8">
          <div className="absolute inset-0 bg-[#222222] flex items-center justify-center">
            <p className="text-white text-center">Imagem de TW O Procurado</p>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
        </div>
        
        <div className="prose prose-lg prose-invert max-w-none">
          <p className="text-[#999999] text-xl leading-relaxed">
            TW O Procurado é um artista de trap brasileiro com mais de 20 anos de experiência musical. 
            Sua jornada no mundo da música começou muito antes do trap se tornar popular no Brasil, 
            mas foi em 2019 que ele encontrou sua verdadeira voz neste gênero com o lançamento do álbum 
            "A Bandida e o Procurado".
          </p>
        </div>
      </section>
      
      {/* História */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">História</h2>
        
        <div className="space-y-8 prose prose-lg prose-invert max-w-none">
          <div>
            <h3 className="text-[#39FF14] text-xl font-bold">Primeiros Anos</h3>
            <p className="text-[#999999] leading-relaxed">
              Nascido e criado nas periferias brasileiras, TW O Procurado sempre teve a música como 
              forma de expressão. Desde jovem, foi influenciado pelo hip-hop nacional e internacional, 
              desenvolvendo um estilo único que mistura a realidade das ruas com reflexões profundas 
              sobre a vida.
            </p>
          </div>
          
          <div>
            <h3 className="text-[#39FF14] text-xl font-bold">Grupo Porventura (2017)</h3>
            <p className="text-[#999999] leading-relaxed">
              Antes de seguir carreira solo, TW fez parte do grupo Porventura, onde começou a 
              experimentar com sonoridades que mais tarde definiriam seu estilo no trap. O grupo 
              ganhou reconhecimento na cena underground e abriu portas para sua carreira solo.
            </p>
          </div>
          
          <div>
            <h3 className="text-[#39FF14] text-xl font-bold">Carreira Solo (2019-presente)</h3>
            <p className="text-[#999999] leading-relaxed">
              Em 2019, TW O Procurado lançou seu primeiro álbum solo, "A Bandida e o Procurado", 
              que incluía hits como "Gosto de Liberdade" e "Roda Gigante". O álbum marcou sua 
              transição definitiva para o trap e estabeleceu sua identidade musical.
            </p>
            <p className="text-[#999999] leading-relaxed">
              Em 2023, lançou "Limbo", seu segundo álbum, que mostrou uma evolução em seu som e 
              letras ainda mais introspectivas. O álbum foi bem recebido pela crítica e expandiu 
              sua base de fãs.
            </p>
          </div>
        </div>
      </section>
      
      {/* Linha do Tempo */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Linha do Tempo</h2>
        
        <div className="relative border-l-2 border-[#39FF14] pl-8 space-y-12">
          <div className="relative">
            <div className="absolute -left-10 mt-1.5 h-4 w-4 rounded-full bg-[#39FF14]"></div>
            <h3 className="text-white text-xl font-bold">2017</h3>
            <p className="text-[#999999]">Formação do grupo Porventura</p>
          </div>
          
          <div className="relative">
            <div className="absolute -left-10 mt-1.5 h-4 w-4 rounded-full bg-[#39FF14]"></div>
            <h3 className="text-white text-xl font-bold">2019</h3>
            <p className="text-[#999999]">Lançamento do álbum "A Bandida e o Procurado"</p>
            <p className="text-[#999999]">Primeiro show solo esgotado</p>
          </div>
          
          <div className="relative">
            <div className="absolute -left-10 mt-1.5 h-4 w-4 rounded-full bg-[#39FF14]"></div>
            <h3 className="text-white text-xl font-bold">2021</h3>
            <p className="text-[#999999]">Colaboração com artistas renomados do trap nacional</p>
            <p className="text-[#999999]">Primeira turnê nacional</p>
          </div>
          
          <div className="relative">
            <div className="absolute -left-10 mt-1.5 h-4 w-4 rounded-full bg-[#39FF14]"></div>
            <h3 className="text-white text-xl font-bold">2023</h3>
            <p className="text-[#999999]">Lançamento do álbum "Limbo"</p>
            <p className="text-[#999999]">Participação em grandes festivais de música</p>
          </div>
          
          <div className="relative">
            <div className="absolute -left-10 mt-1.5 h-4 w-4 rounded-full bg-[#39FF14]"></div>
            <h3 className="text-white text-xl font-bold">2025</h3>
            <p className="text-[#999999]">Preparação para novo álbum</p>
            <p className="text-[#999999]">Turnê nacional e internacional</p>
          </div>
        </div>
      </section>
      
      {/* Influências */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Influências e Estilo</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-[#222222] rounded-lg p-6">
            <h3 className="text-[#39FF14] text-xl font-bold mb-4">Influências Musicais</h3>
            <ul className="space-y-2 text-[#999999]">
              <li>• Rap nacional dos anos 90 e 2000</li>
              <li>• Trap americano contemporâneo</li>
              <li>• Hip-hop clássico</li>
              <li>• Música brasileira tradicional</li>
              <li>• Post Malone</li>
              <li>• Travis Scott</li>
            </ul>
          </div>
          
          <div className="bg-[#222222] rounded-lg p-6">
            <h3 className="text-[#39FF14] text-xl font-bold mb-4">Estilo e Identidade</h3>
            <ul className="space-y-2 text-[#999999]">
              <li>• Letras introspectivas e reflexivas</li>
              <li>• Batidas trap com elementos da cultura brasileira</li>
              <li>• Estética visual urbana com toques vintage</li>
              <li>• Performances energéticas</li>
              <li>• Experimentação sonora</li>
            </ul>
          </div>
        </div>
      </section>
      
      {/* Citações */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Citações</h2>
        
        <div className="bg-[#222222] rounded-lg p-8 border-l-4 border-[#39FF14]">
          <blockquote className="text-xl text-white italic mb-4">
            "Minha música é um reflexo das ruas, das experiências vividas e das batalhas enfrentadas. 
            Cada letra carrega um pedaço da minha história e da história de muitos que se identificam com ela."
          </blockquote>
          <p className="text-[#39FF14] font-medium">— TW O Procurado</p>
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="mb-16">
        <Newsletter />
      </section>
    </div>
  );
}
