import React from 'react';

const HomePage = () => {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/processed/hero.jpg" 
            alt="TW O Procurado" 
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        </div>
        
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
          <h1 className="text-6xl md:text-8xl font-bold mb-4 text-neon-green glow-text tracking-wider">
            TW O PROCURADO
          </h1>
          <p className="text-xl md:text-2xl text-white mb-8 max-w-2xl">
            Artista trap brasileiro com mais de 20 anos de experiência musical
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a 
              href="/musica" 
              className="px-8 py-3 bg-neon-green text-black font-bold rounded-full hover:bg-opacity-80 transition-all duration-300 transform hover:scale-105"
            >
              OUVIR AGORA
            </a>
            <a 
              href="/agenda" 
              className="px-8 py-3 bg-transparent border-2 border-neon-green text-neon-green font-bold rounded-full hover:bg-neon-green hover:bg-opacity-20 transition-all duration-300 transform hover:scale-105"
            >
              PRÓXIMOS SHOWS
            </a>
          </div>
        </div>
      </section>

      {/* Latest Release Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-neon-green glow-text">
            LANÇAMENTO RECENTE
          </h2>
          
          <div className="flex flex-col md:flex-row items-center gap-8 max-w-4xl mx-auto">
            <div className="w-full md:w-1/2">
              <img 
                src="/images/processed/tw_o_procurado_5.jpg" 
                alt="Álbum Limbo" 
                className="w-full h-auto rounded-lg shadow-neon"
              />
            </div>
            
            <div className="w-full md:w-1/2">
              <h3 className="text-2xl font-bold mb-2 text-white">LIMBO (2023)</h3>
              <p className="text-gray-300 mb-6">
                O mais recente álbum de TW O Procurado explora temas profundos com batidas trap inovadoras e letras impactantes.
              </p>
              
              <div className="flex flex-wrap gap-3 mb-6">
                <span className="px-3 py-1 bg-gray-800 text-gray-300 text-sm rounded-full">Trap</span>
                <span className="px-3 py-1 bg-gray-800 text-gray-300 text-sm rounded-full">Hip Hop</span>
                <span className="px-3 py-1 bg-gray-800 text-gray-300 text-sm rounded-full">Brasileiro</span>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <a 
                  href="https://open.spotify.com/artist/2AhriT8wvRfy1s1agFJYeS" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-[#1DB954] text-black font-bold rounded-full hover:bg-opacity-80 transition-all"
                >
                  <span>Spotify</span>
                </a>
                <a 
                  href="https://www.youtube.com/watch?v=5OUbCSanJ_s" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-[#FF0000] text-white font-bold rounded-full hover:bg-opacity-80 transition-all"
                >
                  <span>YouTube</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Preview */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-neon-green glow-text">
            GALERIA
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            <img src="/images/processed/tw_o_procurado_1.jpg" alt="TW O Procurado" className="w-full h-64 object-cover rounded-lg" />
            <img src="/images/processed/tw_o_procurado_3.jpg" alt="TW O Procurado" className="w-full h-64 object-cover rounded-lg" />
            <img src="/images/processed/tw_o_procurado_7.jpg" alt="TW O Procurado" className="w-full h-64 object-cover rounded-lg" />
          </div>
          
          <div className="text-center">
            <a 
              href="/galeria" 
              className="inline-block px-8 py-3 bg-transparent border-2 border-neon-green text-neon-green font-bold rounded-full hover:bg-neon-green hover:bg-opacity-20 transition-all duration-300"
            >
              VER MAIS FOTOS
            </a>
          </div>
        </div>
      </section>

      {/* Upcoming Shows */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center text-neon-green glow-text">
            PRÓXIMOS SHOWS
          </h2>
          
          <div className="max-w-3xl mx-auto">
            <div className="bg-black bg-opacity-50 rounded-lg overflow-hidden mb-6">
              <div className="p-6 border-l-4 border-neon-green">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">São Paulo, SP</h3>
                    <p className="text-gray-400">Cena Trap Festival</p>
                  </div>
                  <div className="text-right">
                    <p className="text-neon-green font-bold">15 Maio 2025</p>
                    <p className="text-gray-400">21:00</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-black bg-opacity-50 rounded-lg overflow-hidden mb-6">
              <div className="p-6 border-l-4 border-neon-green">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">Rio de Janeiro, RJ</h3>
                    <p className="text-gray-400">Trap Nation Brasil</p>
                  </div>
                  <div className="text-right">
                    <p className="text-neon-green font-bold">22 Maio 2025</p>
                    <p className="text-gray-400">22:00</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center mt-8">
              <a 
                href="/agenda" 
                className="inline-block px-8 py-3 bg-transparent border-2 border-neon-green text-neon-green font-bold rounded-full hover:bg-neon-green hover:bg-opacity-20 transition-all duration-300"
              >
                VER AGENDA COMPLETA
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-neon-green glow-text">
              FIQUE POR DENTRO
            </h2>
            <p className="text-gray-300 mb-8">
              Inscreva-se para receber novidades sobre lançamentos, shows e conteúdo exclusivo.
            </p>
            
            <form className="flex flex-col md:flex-row gap-4 justify-center">
              <input 
                type="email" 
                placeholder="Seu melhor e-mail" 
                className="px-6 py-3 bg-gray-900 text-white rounded-full focus:outline-none focus:ring-2 focus:ring-neon-green w-full md:w-auto"
              />
              <button 
                type="submit" 
                className="px-8 py-3 bg-neon-green text-black font-bold rounded-full hover:bg-opacity-80 transition-all duration-300"
              >
                INSCREVER
              </button>
            </form>
          </div>
        </div>
      </section>
    </main>
  );
};

export default HomePage;
