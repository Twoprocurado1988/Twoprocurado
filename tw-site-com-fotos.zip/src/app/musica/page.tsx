import React from 'react';
import MusicPlayer from '@/components/MusicPlayer';
import TrackList from '@/components/TrackList';
import Link from 'next/link';

export default function MusicaPage() {
  // Dados fictícios de álbuns (seriam substituídos por dados reais)
  const albums = [
    { 
      id: 1, 
      title: 'A Bandida e o Procurado', 
      year: '2019',
      cover: '/images/album1.jpg',
      tracks: [
        { id: 1, title: 'Gosto de Liberdade', duration: '3:20' },
        { id: 2, title: 'Roda Gigante', duration: '2:45' },
        { id: 3, title: 'Carro', duration: '3:05' },
      ]
    },
    { 
      id: 2, 
      title: 'Limbo', 
      year: '2023',
      cover: '/images/album2.jpg',
      tracks: [
        { id: 1, title: 'Efeito Bipolar', duration: '3:12' },
        { id: 2, title: 'Limbo', duration: '2:58' },
      ]
    },
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-white mb-8">Música</h1>
      
      {/* Player Principal */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Ouça Agora</h2>
        <MusicPlayer />
      </section>
      
      {/* Lista de Faixas */}
      <section className="mb-16">
        <TrackList />
      </section>
      
      {/* Discografia */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Discografia</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {albums.map((album) => (
            <div key={album.id} className="bg-[#222222] rounded-lg overflow-hidden group hover:bg-[#333333] transition-colors duration-300">
              <div className="relative aspect-square overflow-hidden">
                <div className="absolute inset-0 bg-[#111111] flex items-center justify-center">
                  <p className="text-white text-center p-4">{album.title}</p>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <button className="w-16 h-16 rounded-full flex items-center justify-center bg-[#39FF14] text-black hover:bg-white transition-colors duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="text-white font-bold">{album.title}</h3>
                <p className="text-[#999999]">{album.year}</p>
                <p className="text-[#999999] text-sm mt-1">{album.tracks.length} faixas</p>
                
                <button className="mt-4 w-full py-2 bg-transparent border border-[#39FF14] text-[#39FF14] rounded-md hover:bg-[#39FF14] hover:text-black transition-colors duration-300">
                  Ouvir
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
      
      {/* Colaborações */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Colaborações</h2>
        
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row items-center bg-[#222222] rounded-lg overflow-hidden p-4">
            <div className="w-full md:w-1/6 aspect-square bg-[#111111] flex items-center justify-center mb-4 md:mb-0 md:mr-6">
              <p className="text-white text-center">Capa</p>
            </div>
            
            <div className="flex-1">
              <h3 className="text-white font-bold text-lg">Título da Música</h3>
              <p className="text-[#999999]">feat. Artista Colaborador</p>
              <p className="text-[#999999] text-sm mt-1">2022</p>
            </div>
            
            <button className="mt-4 md:mt-0 md:ml-4 px-6 py-2 bg-transparent border border-[#39FF14] text-[#39FF14] rounded-md hover:bg-[#39FF14] hover:text-black transition-colors duration-300">
              Ouvir
            </button>
          </div>
          
          <div className="flex flex-col md:flex-row items-center bg-[#222222] rounded-lg overflow-hidden p-4">
            <div className="w-full md:w-1/6 aspect-square bg-[#111111] flex items-center justify-center mb-4 md:mb-0 md:mr-6">
              <p className="text-white text-center">Capa</p>
            </div>
            
            <div className="flex-1">
              <h3 className="text-white font-bold text-lg">Título da Música</h3>
              <p className="text-[#999999]">feat. Artista Colaborador</p>
              <p className="text-[#999999] text-sm mt-1">2021</p>
            </div>
            
            <button className="mt-4 md:mt-0 md:ml-4 px-6 py-2 bg-transparent border border-[#39FF14] text-[#39FF14] rounded-md hover:bg-[#39FF14] hover:text-black transition-colors duration-300">
              Ouvir
            </button>
          </div>
        </div>
      </section>
      
      {/* Estatísticas */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Estatísticas</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="bg-[#222222] rounded-lg p-6 text-center">
            <h3 className="text-[#39FF14] text-3xl font-bold mb-2">40,129</h3>
            <p className="text-white font-medium">Streams</p>
            <p className="text-[#999999] text-sm">Gosto de Liberdade</p>
          </div>
          
          <div className="bg-[#222222] rounded-lg p-6 text-center">
            <h3 className="text-[#39FF14] text-3xl font-bold mb-2">20,985</h3>
            <p className="text-white font-medium">Streams</p>
            <p className="text-[#999999] text-sm">Roda Gigante</p>
          </div>
          
          <div className="bg-[#222222] rounded-lg p-6 text-center">
            <h3 className="text-[#39FF14] text-3xl font-bold mb-2">19,877</h3>
            <p className="text-white font-medium">Streams</p>
            <p className="text-[#999999] text-sm">Carro</p>
          </div>
          
          <div className="bg-[#222222] rounded-lg p-6 text-center">
            <h3 className="text-[#39FF14] text-3xl font-bold mb-2">17,614</h3>
            <p className="text-white font-medium">Streams</p>
            <p className="text-[#999999] text-sm">Efeito Bipolar</p>
          </div>
        </div>
      </section>
    </div>
  );
}
