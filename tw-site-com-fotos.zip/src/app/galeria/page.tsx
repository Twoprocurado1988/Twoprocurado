import React from 'react';

const GaleriaPage = () => {
  // Array com as imagens processadas
  const images = [
    { src: '/images/processed/tw_o_procurado_1.jpg', alt: 'TW O Procurado em performance' },
    { src: '/images/processed/tw_o_procurado_2.jpg', alt: 'TW O Procurado com parceiro musical' },
    { src: '/images/processed/tw_o_procurado_3.jpg', alt: 'TW O Procurado em estúdio' },
    { src: '/images/processed/tw_o_procurado_4.jpg', alt: 'TW O Procurado em show' },
    { src: '/images/processed/tw_o_procurado_5.jpg', alt: 'TW O Procurado com microfone' },
    { src: '/images/processed/tw_o_procurado_6.jpg', alt: 'TW O Procurado em performance ao vivo' },
    { src: '/images/processed/tw_o_procurado_7.jpg', alt: 'TW O Procurado no palco' },
    { src: '/images/processed/tw_o_procurado_8.jpg', alt: 'TW O Procurado com fãs' },
    { src: '/images/processed/tw_o_procurado_9.jpg', alt: 'TW O Procurado em sessão de fotos' },
    { src: '/images/processed/tw_o_procurado_10.jpg', alt: 'TW O Procurado perfil artístico' },
  ];

  return (
    <main className="container mx-auto px-4 py-16">
      <h1 className="text-4xl md:text-5xl font-bold mb-6 text-center text-neon-green glow-text">GALERIA</h1>
      
      <p className="text-gray-300 text-center max-w-3xl mx-auto mb-12">
        Confira os registros dos shows, bastidores e momentos especiais da carreira de TW O Procurado.
        Imagens que capturam a essência do trap e a energia das performances ao vivo.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((image, index) => (
          <div 
            key={index} 
            className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-neon transition-all duration-300 hover:scale-[1.02] group"
          >
            <img 
              src={image.src} 
              alt={image.alt} 
              className="w-full h-64 object-cover object-center"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <span className="text-white text-lg font-bold px-4 py-2 border border-neon-green rounded-full glow-border">
                {image.alt}
              </span>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-6 text-neon-green">VÍDEOS</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
            <p className="text-gray-400">Videoclipe "Gosto de Liberdade" - Em breve</p>
          </div>
          <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
            <p className="text-gray-400">Videoclipe "Roda Gigante" - Em breve</p>
          </div>
        </div>
      </div>
    </main>
  );
};

export default GaleriaPage;
