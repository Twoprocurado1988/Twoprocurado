import React from 'react';
import Newsletter from '@/components/Newsletter';

export default function ContatoPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-white mb-8">Contato</h1>
      
      {/* Informações de Contato */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Entre em Contato</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#222222] rounded-lg p-6">
            <h3 className="text-[#39FF14] text-xl font-bold mb-4">Booking e Shows</h3>
            <p className="text-white font-medium">Nome do Responsável</p>
            <p className="text-[#999999] mb-2">contato@twoprocurado.com.br</p>
            <p className="text-[#999999]">+55 (XX) XXXXX-XXXX</p>
          </div>
          
          <div className="bg-[#222222] rounded-lg p-6">
            <h3 className="text-[#39FF14] text-xl font-bold mb-4">Assessoria de Imprensa</h3>
            <p className="text-white font-medium">Nome do Responsável</p>
            <p className="text-[#999999] mb-2">imprensa@twoprocurado.com.br</p>
            <p className="text-[#999999]">+55 (XX) XXXXX-XXXX</p>
          </div>
          
          <div className="bg-[#222222] rounded-lg p-6">
            <h3 className="text-[#39FF14] text-xl font-bold mb-4">Parcerias e Negócios</h3>
            <p className="text-white font-medium">Nome do Responsável</p>
            <p className="text-[#999999] mb-2">negocios@twoprocurado.com.br</p>
            <p className="text-[#999999]">+55 (XX) XXXXX-XXXX</p>
          </div>
        </div>
      </section>
      
      {/* Formulário de Contato */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Envie uma Mensagem</h2>
        
        <div className="bg-[#222222] rounded-lg p-8">
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-white font-medium mb-2">Nome Completo*</label>
                <input 
                  type="text" 
                  id="name" 
                  className="w-full px-4 py-3 bg-[#333333] text-white rounded-md focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-white font-medium mb-2">E-mail*</label>
                <input 
                  type="email" 
                  id="email" 
                  className="w-full px-4 py-3 bg-[#333333] text-white rounded-md focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="phone" className="block text-white font-medium mb-2">Telefone</label>
                <input 
                  type="tel" 
                  id="phone" 
                  className="w-full px-4 py-3 bg-[#333333] text-white rounded-md focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                />
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-white font-medium mb-2">Assunto*</label>
                <select 
                  id="subject" 
                  className="w-full px-4 py-3 bg-[#333333] text-white rounded-md focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                  required
                >
                  <option value="">Selecione uma opção</option>
                  <option value="shows">Contratação para Shows</option>
                  <option value="press">Imprensa</option>
                  <option value="partnership">Parcerias</option>
                  <option value="fan">Mensagem de Fã</option>
                  <option value="other">Outro</option>
                </select>
              </div>
            </div>
            
            <div>
              <label htmlFor="message" className="block text-white font-medium mb-2">Mensagem*</label>
              <textarea 
                id="message" 
                rows={6} 
                className="w-full px-4 py-3 bg-[#333333] text-white rounded-md focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
                required
              ></textarea>
            </div>
            
            <div>
              <button 
                type="submit" 
                className="px-8 py-4 bg-[#39FF14] text-black font-bold rounded-md hover:bg-white transition-colors duration-300"
              >
                Enviar Mensagem
              </button>
            </div>
          </form>
        </div>
      </section>
      
      {/* Redes Sociais */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Siga nas Redes Sociais</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          <a 
            href="https://open.spotify.com/artist/2AhriT8wvRfy1s1agFJYeS" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="bg-[#222222] rounded-lg p-6 flex flex-col items-center text-center hover:bg-[#333333] transition-colors duration-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-4">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M8 14.5c2.5-1 5.5-1 8 0"></path>
              <path d="M6.5 12c3.5-1 7.5-1 11 0"></path>
              <path d="M8 9.5c2.5-1 5.5-1 8 0"></path>
            </svg>
            <h3 className="text-white font-bold mb-1">Spotify</h3>
            <p className="text-[#999999]">@twoprocurado</p>
          </a>
          
          <a 
            href="https://www.instagram.com/twoprocurado/" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="bg-[#222222] rounded-lg p-6 flex flex-col items-center text-center hover:bg-[#333333] transition-colors duration-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#E1306C" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-4">
              <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
              <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
            </svg>
            <h3 className="text-white font-bold mb-1">Instagram</h3>
            <p className="text-[#999999]">@twoprocurado</p>
          </a>
          
          <a 
            href="https://www.youtube.com/watch?v=5OUbCSanJ_s" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="bg-[#222222] rounded-lg p-6 flex flex-col items-center text-center hover:bg-[#333333] transition-colors duration-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#FF0000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-4">
              <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
              <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
            </svg>
            <h3 className="text-white font-bold mb-1">YouTube</h3>
            <p className="text-[#999999]">TW O Procurado</p>
          </a>
          
          <a 
            href="#" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="bg-[#222222] rounded-lg p-6 flex flex-col items-center text-center hover:bg-[#333333] transition-colors duration-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#00F2EA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mb-4">
              <path d="M9 12A3 3 0 1 0 9 6a3 3 0 0 0 0 6Z"></path>
              <path d="M9 18a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"></path>
              <path d="M15 6a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"></path>
              <path d="M15 18a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"></path>
            </svg>
            <h3 className="text-white font-bold mb-1">TikTok</h3>
            <p className="text-[#999999]">@twoprocurado</p>
          </a>
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="mb-16">
        <Newsletter />
      </section>
    </div>
  );
}
