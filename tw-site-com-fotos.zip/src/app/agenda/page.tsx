import React from 'react';
import ShowsList from '@/components/ShowsList';
import Newsletter from '@/components/Newsletter';

export default function AgendaPage() {
  // Dados fictícios de shows (seriam substituídos por dados reais)
  const shows = [
    { id: 1, date: '15/05/2025', city: 'São Paulo', venue: 'Audio Club', ticketLink: '#' },
    { id: 2, date: '22/05/2025', city: 'Rio de Janeiro', venue: 'Circo Voador', ticketLink: '#' },
    { id: 3, date: '29/05/2025', city: 'Belo Horizonte', venue: 'Autêntica', ticketLink: '#' },
    { id: 4, date: '05/06/2025', city: 'Curitiba', venue: 'Ópera de Arame', ticketLink: '#' },
    { id: 5, date: '12/06/2025', city: 'Porto Alegre', venue: 'Bar Opinião', ticketLink: '#' },
    { id: 6, date: '19/06/2025', city: 'Brasília', venue: 'Clube do Choro', ticketLink: '#' },
    { id: 7, date: '26/06/2025', city: 'Salvador', venue: 'Concha Acústica', ticketLink: '#' },
    { id: 8, date: '03/07/2025', city: 'Recife', venue: 'Classic Hall', ticketLink: '#' },
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold text-white mb-8">Agenda de Shows</h1>
      
      {/* Mapa Interativo */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Próximos Shows</h2>
        
        <div className="bg-[#222222] rounded-lg p-6 mb-8">
          <div className="aspect-video bg-[#111111] flex items-center justify-center mb-6">
            <p className="text-white text-center">Mapa Interativo do Brasil com marcadores de shows</p>
          </div>
          
          <p className="text-[#999999]">
            Clique nos marcadores para ver detalhes dos shows e comprar ingressos.
          </p>
        </div>
        
        {/* Lista de Shows */}
        <div className="space-y-4">
          {shows.map((show) => (
            <div key={show.id} className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-[#222222] rounded-md hover:bg-[#333333] transition-colors duration-300">
              <div className="flex flex-col md:flex-row md:items-center mb-4 md:mb-0">
                <div className="bg-black p-4 rounded-md text-center mb-4 md:mb-0 md:mr-6">
                  <span className="block text-[#39FF14] text-2xl font-bold">{show.date.split('/')[0]}</span>
                  <span className="block text-white text-sm">{show.date.split('/')[1]}/{show.date.split('/')[2]}</span>
                </div>
                
                <div>
                  <h4 className="text-white font-medium text-xl">{show.city}</h4>
                  <p className="text-[#999999] text-lg">{show.venue}</p>
                </div>
              </div>
              
              <a 
                href={show.ticketLink} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-block px-6 py-3 bg-transparent border border-[#39FF14] text-[#39FF14] rounded-md hover:bg-[#39FF14] hover:text-black transition-colors duration-300 text-center"
              >
                Comprar Ingressos
              </a>
            </div>
          ))}
        </div>
      </section>
      
      {/* Histórico de Shows */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Shows Anteriores</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-[#222222] rounded-lg overflow-hidden group">
            <div className="aspect-video bg-[#111111] flex items-center justify-center">
              <p className="text-white text-center">Foto do Show</p>
            </div>
            
            <div className="p-4">
              <h3 className="text-white font-bold">São Paulo</h3>
              <p className="text-[#999999]">Audio Club</p>
              <p className="text-[#999999] text-sm">15/01/2025</p>
            </div>
          </div>
          
          <div className="bg-[#222222] rounded-lg overflow-hidden group">
            <div className="aspect-video bg-[#111111] flex items-center justify-center">
              <p className="text-white text-center">Foto do Show</p>
            </div>
            
            <div className="p-4">
              <h3 className="text-white font-bold">Rio de Janeiro</h3>
              <p className="text-[#999999]">Circo Voador</p>
              <p className="text-[#999999] text-sm">22/01/2025</p>
            </div>
          </div>
          
          <div className="bg-[#222222] rounded-lg overflow-hidden group">
            <div className="aspect-video bg-[#111111] flex items-center justify-center">
              <p className="text-white text-center">Foto do Show</p>
            </div>
            
            <div className="p-4">
              <h3 className="text-white font-bold">Belo Horizonte</h3>
              <p className="text-[#999999]">Autêntica</p>
              <p className="text-[#999999] text-sm">29/01/2025</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Informações para Contratação */}
      <section className="mb-16">
        <h2 className="text-2xl font-bold text-white mb-6">Contratação para Shows</h2>
        
        <div className="bg-[#222222] rounded-lg p-6">
          <p className="text-white mb-4">
            Para contratação de shows, entre em contato com nossa equipe:
          </p>
          
          <div className="mb-4">
            <h3 className="text-[#39FF14] font-bold">Booking</h3>
            <p className="text-white">Nome do Responsável</p>
            <p className="text-[#999999]">contato@twoprocurado.com.br</p>
            <p className="text-[#999999]">+55 (XX) XXXXX-XXXX</p>
          </div>
          
          <a 
            href="/contato" 
            className="inline-block px-6 py-3 bg-[#39FF14] text-black font-bold rounded-md hover:bg-white transition-colors duration-300"
          >
            Formulário de Contato
          </a>
        </div>
      </section>
      
      {/* Newsletter */}
      <section className="mb-16">
        <Newsletter />
      </section>
    </div>
  );
}
