// Arquivo de configuração para imagens de placeholder
// Este arquivo define URLs de imagens de placeholder para uso no site

export const placeholderImages = {
  // Álbuns
  album1: 'https://placehold.co/500x500/222222/FFFFFF/png?text=A+Bandida+e+o+Procurado',
  album2: 'https://placehold.co/500x500/222222/FFFFFF/png?text=Limbo',
  
  // Galeria
  placeholder1: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+1',
  placeholder2: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+2',
  placeholder3: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+3',
  placeholder4: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+4',
  placeholder5: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+5',
  placeholder6: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+6',
  placeholder7: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+7',
  placeholder8: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+8',
  placeholder9: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+9',
  placeholder10: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+10',
  placeholder11: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+11',
  placeholder12: 'https://placehold.co/400x400/222222/FFFFFF/png?text=TW+O+Procurado+12',
  
  // Vídeos
  video1: 'https://placehold.co/600x400/222222/FFFFFF/png?text=Videoclipe+1',
  video2: 'https://placehold.co/600x400/222222/FFFFFF/png?text=Videoclipe+2',
  video3: 'https://placehold.co/600x400/222222/FFFFFF/png?text=Entrevista',
  
  // Hero
  hero: 'https://placehold.co/1920x1080/222222/FFFFFF/png?text=TW+O+Procurado',
  
  // Biografia
  bio: 'https://placehold.co/1200x600/222222/FFFFFF/png?text=Biografia+TW+O+Procurado',
  
  // Shows
  show1: 'https://placehold.co/600x400/222222/FFFFFF/png?text=Show+São+Paulo',
  show2: 'https://placehold.co/600x400/222222/FFFFFF/png?text=Show+Rio+de+Janeiro',
  show3: 'https://placehold.co/600x400/222222/FFFFFF/png?text=Show+Belo+Horizonte',
};
