import { placeholderImages } from '@/lib/placeholders';
import Image from 'next/image';

const MusicPlayer = () => {
  return (
    <div className="music-player">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-1/3">
          <div className="relative aspect-square overflow-hidden rounded-md neon-border">
            <div className="absolute inset-0 bg-gradient-to-br from-[#39FF14]/20 to-transparent z-10"></div>
            <Image 
              src={placeholderImages.album1} 
              alt="A Bandida e o Procurado"
              width={500}
              height={500}
              className="object-cover w-full h-full"
            />
          </div>
        </div>
        
        <div className="w-full md:w-2/3 flex flex-col justify-between">
          <div>
            <h3 className="text-2xl font-bold text-white mb-1">Gosto de Liberdade</h3>
            <p className="text-[#999999] mb-6">A Bandida e o Procurado (2019)</p>
          </div>
          
          <div className="mb-6">
            <div className="h-2 bg-[#222222] rounded-full mb-2 overflow-hidden">
              <div className="h-full w-[60%] bg-[#39FF14] rounded-full"></div>
            </div>
            <div className="flex justify-between text-sm text-[#999999]">
              <span>1:45</span>
              <span>3:20</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button className="w-12 h-12 rounded-full flex items-center justify-center bg-[#222222] text-white hover:bg-[#39FF14] hover:text-black transition-colors duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="19 20 9 12 19 4 19 20"></polygon>
                  <line x1="5" y1="19" x2="5" y2="5"></line>
                </svg>
              </button>
              
              <button className="w-16 h-16 rounded-full flex items-center justify-center bg-[#39FF14] text-black hover:bg-white transition-colors duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="5 3 19 12 5 21 5 3"></polygon>
                </svg>
              </button>
              
              <button className="w-12 h-12 rounded-full flex items-center justify-center bg-[#222222] text-white hover:bg-[#39FF14] hover:text-black transition-colors duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="5 4 15 12 5 20 5 4"></polygon>
                  <line x1="19" y1="5" x2="19" y2="19"></line>
                </svg>
              </button>
            </div>
            
            <div className="flex items-center space-x-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-[#999999]">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
              </svg>
              
              <div className="w-24 h-2 bg-[#222222] rounded-full overflow-hidden">
                <div className="h-full w-[70%] bg-[#999999] rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-8 flex flex-wrap gap-4">
        <a href="https://open.spotify.com/artist/2AhriT8wvRfy1s1agFJYeS" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center px-4 py-2 bg-[#1DB954] text-white rounded-full hover:bg-[#1ED760] transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M8 14.5c2.5-1 5.5-1 8 0"></path>
            <path d="M6.5 12c3.5-1 7.5-1 11 0"></path>
            <path d="M8 9.5c2.5-1 5.5-1 8 0"></path>
          </svg>
          <span>Spotify</span>
        </a>
        
        <a href="https://www.youtube.com/watch?v=5OUbCSanJ_s" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center px-4 py-2 bg-[#FF0000] text-white rounded-full hover:bg-[#FF3333] transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
            <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
            <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
          </svg>
          <span>YouTube</span>
        </a>
        
        <a href="#" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center px-4 py-2 bg-[#FA243C] text-white rounded-full hover:bg-[#FA455C] transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
            <path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z"></path>
            <path d="M8 12h8"></path>
            <path d="M12 8v8"></path>
          </svg>
          <span>Apple Music</span>
        </a>
        
        <a href="#" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center px-4 py-2 bg-[#0D72EA] text-white rounded-full hover:bg-[#2D92FA] transition-colors duration-300">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
            <path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z"></path>
            <path d="M8 12h8"></path>
          </svg>
          <span>Deezer</span>
        </a>
      </div>
    </div>
  );
};

export default MusicPlayer;
