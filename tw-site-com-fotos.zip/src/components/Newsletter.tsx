import React from 'react';

const Newsletter = () => {
  return (
    <div className="bg-[#111111] rounded-lg p-6 neon-border mt-10">
      <h3 className="text-xl font-bold text-white mb-4">Fique por Dentro</h3>
      <p className="text-[#999999] mb-6">
        Inscreva-se para receber novidades, lançamentos exclusivos e datas de shows.
      </p>
      
      <form className="flex flex-col sm:flex-row gap-4">
        <input 
          type="email" 
          placeholder="Seu melhor e-mail" 
          className="flex-1 px-4 py-3 bg-[#222222] text-white rounded-md focus:outline-none focus:ring-2 focus:ring-[#39FF14]"
          required
        />
        <button 
          type="submit" 
          className="px-6 py-3 bg-[#39FF14] text-black font-bold rounded-md hover:bg-white transition-colors duration-300"
        >
          Inscrever-se
        </button>
      </form>
    </div>
  );
};

export default Newsletter;
