import React from 'react';

interface GalleryProps {
  images: {
    src: string;
    alt: string;
  }[];
}

const Gallery: React.FC<GalleryProps> = ({ images }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
      {images.map((image, index) => (
        <div 
          key={index} 
          className="relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] group"
        >
          <img 
            src={image.src} 
            alt={image.alt} 
            className="w-full h-64 object-cover object-center"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <span className="text-white text-lg font-bold px-4 py-2 border border-white rounded-full">
              Ver Imagem
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Gallery;
