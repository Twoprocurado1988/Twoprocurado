import React from 'react';
import Link from 'next/link';

const TrackList = () => {
  const tracks = [
    { id: 1, title: 'Gosto de Liberdade', album: 'A Bandida e o Procurado', duration: '3:20', year: '2019' },
    { id: 2, title: 'Roda Gigante', album: 'A Bandida e o Procurado', duration: '2:45', year: '2019' },
    { id: 3, title: 'Carro', album: 'A Bandida e o Procurado', duration: '3:05', year: '2019' },
    { id: 4, title: 'Efeito Bipolar', album: 'Limbo', duration: '3:12', year: '2023' },
    { id: 5, title: 'Limbo', album: 'Limbo', duration: '2:58', year: '2023' },
  ];

  return (
    <div className="track-list">
      <h3 className="text-xl font-bold text-white mb-4">Faixas</h3>
      
      {tracks.map((track) => (
        <div key={track.id} className="track-item">
          <div className="flex items-center">
            <button className="w-10 h-10 rounded-full flex items-center justify-center bg-[#222222] text-white hover:bg-[#39FF14] hover:text-black transition-colors duration-300 mr-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="5 3 19 12 5 21 5 3"></polygon>
              </svg>
            </button>
            
            <div>
              <h4 className="text-white font-medium">{track.title}</h4>
              <p className="text-sm text-[#999999]">{track.album} • {track.year}</p>
            </div>
          </div>
          
          <div className="flex items-center">
            <span className="text-[#999999] mr-4">{track.duration}</span>
            
            <div className="flex space-x-2">
              <button className="text-[#999999] hover:text-[#39FF14] transition-colors duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 18V5l12-2v13"></path>
                  <circle cx="6" cy="18" r="3"></circle>
                  <circle cx="18" cy="16" r="3"></circle>
                </svg>
              </button>
              
              <button className="text-[#999999] hover:text-[#39FF14] transition-colors duration-300">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
              </button>
            </div>
          </div>
        </div>
      ))}
      
      <div className="mt-6">
        <Link href="/musica" className="text-[#39FF14] hover:text-white transition-colors duration-300 flex items-center">
          <span>Ver discografia completa</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
            <line x1="5" y1="12" x2="19" y2="12"></line>
            <polyline points="12 5 19 12 12 19"></polyline>
          </svg>
        </Link>
      </div>
    </div>
  );
};

export default TrackList;
