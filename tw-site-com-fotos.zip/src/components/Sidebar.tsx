import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

const Sidebar = () => {
  return (
    <aside className="bg-black border-r border-[#222222] w-full md:w-64 md:min-h-screen flex flex-col">
      <div className="p-6">
        <Link href="/" className="block">
          <h1 className="text-2xl font-bold text-white neon-text">TW</h1>
          <p className="text-sm text-[#39FF14]">O PROCURADO</p>
        </Link>
      </div>
      
      <nav className="flex-1 p-6">
        <ul className="space-y-6">
          <li>
            <Link 
              href="/" 
              className="flex items-center text-white hover:text-[#39FF14] transition-colors duration-300"
            >
              <span className="text-lg">Home</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/musica" 
              className="flex items-center text-white hover:text-[#39FF14] transition-colors duration-300"
            >
              <span className="text-lg">Música</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/agenda" 
              className="flex items-center text-white hover:text-[#39FF14] transition-colors duration-300"
            >
              <span className="text-lg">Agenda</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/galeria" 
              className="flex items-center text-white hover:text-[#39FF14] transition-colors duration-300"
            >
              <span className="text-lg">Galeria</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/biografia" 
              className="flex items-center text-white hover:text-[#39FF14] transition-colors duration-300"
            >
              <span className="text-lg">Biografia</span>
            </Link>
          </li>
          <li>
            <Link 
              href="/contato" 
              className="flex items-center text-white hover:text-[#39FF14] transition-colors duration-300"
            >
              <span className="text-lg">Contato</span>
            </Link>
          </li>
        </ul>
      </nav>
      
      <div className="p-6 border-t border-[#222222]">
        <div className="flex space-x-4">
          <a href="https://open.spotify.com/artist/2AhriT8wvRfy1s1agFJYeS" target="_blank" rel="noopener noreferrer" className="text-white hover:text-[#39FF14] transition-colors duration-300">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M8 14.5c2.5-1 5.5-1 8 0"></path>
              <path d="M6.5 12c3.5-1 7.5-1 11 0"></path>
              <path d="M8 9.5c2.5-1 5.5-1 8 0"></path>
            </svg>
          </a>
          <a href="https://www.youtube.com/watch?v=5OUbCSanJ_s" target="_blank" rel="noopener noreferrer" className="text-white hover:text-[#39FF14] transition-colors duration-300">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
              <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
            </svg>
          </a>
          <a href="https://www.instagram.com/twoprocurado/" target="_blank" rel="noopener noreferrer" className="text-white hover:text-[#39FF14] transition-colors duration-300">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
              <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
            </svg>
          </a>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
