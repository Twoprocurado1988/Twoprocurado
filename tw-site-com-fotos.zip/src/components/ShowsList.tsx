import React from 'react';
import Link from 'next/link';

const ShowsList = () => {
  // Dados fictícios de shows (seriam substituídos por dados reais)
  const shows = [
    { id: 1, date: '15/05/2025', city: 'São Paulo', venue: 'Audio Club', ticketLink: '#' },
    { id: 2, date: '22/05/2025', city: 'Rio de Janeiro', venue: 'Circo Voador', ticketLink: '#' },
    { id: 3, date: '29/05/2025', city: 'Belo Horizonte', venue: 'Autêntica', ticketLink: '#' },
  ];

  return (
    <div className="bg-[#111111] rounded-lg p-6 neon-border">
      <h3 className="text-xl font-bold text-white mb-6">Próximos Shows</h3>
      
      <div className="space-y-4">
        {shows.map((show) => (
          <div key={show.id} className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-[#222222] rounded-md hover:bg-[#333333] transition-colors duration-300">
            <div className="flex flex-col md:flex-row md:items-center mb-4 md:mb-0">
              <div className="bg-black p-3 rounded-md text-center mb-4 md:mb-0 md:mr-6">
                <span className="block text-[#39FF14] text-xl font-bold">{show.date.split('/')[0]}</span>
                <span className="block text-white text-sm">{show.date.split('/')[1]}/{show.date.split('/')[2]}</span>
              </div>
              
              <div>
                <h4 className="text-white font-medium text-lg">{show.city}</h4>
                <p className="text-[#999999]">{show.venue}</p>
              </div>
            </div>
            
            <a 
              href={show.ticketLink} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="inline-block px-4 py-2 bg-transparent border border-[#39FF14] text-[#39FF14] rounded-md hover:bg-[#39FF14] hover:text-black transition-colors duration-300 text-center"
            >
              Ingressos
            </a>
          </div>
        ))}
      </div>
      
      <div className="mt-6">
        <Link href="/agenda" className="text-[#39FF14] hover:text-white transition-colors duration-300 flex items-center">
          <span>Ver agenda completa</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
            <line x1="5" y1="12" x2="19" y2="12"></line>
            <polyline points="12 5 19 12 12 19"></polyline>
          </svg>
        </Link>
      </div>
    </div>
  );
};

export default ShowsList;
